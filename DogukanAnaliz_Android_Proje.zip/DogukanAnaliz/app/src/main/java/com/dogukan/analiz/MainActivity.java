package com.dogukan.analiz;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
  final int bg=Color.rgb(13,22,36), panel=Color.rgb(26,42,60), green=Color.rgb(76,222,142), muted=Color.rgb(168,185,203);
  LinearLayout root, content, tabs;
  String competition="Süper Lig";
  String period="Son 5";
  int page=0;
  @Override public void onCreate(Bundle b){super.onCreate(b);show();}
  GradientDrawable shape(int c,int radius){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(radius);return d;}
  TextView text(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);if(bold)v.setTypeface(null,Typeface.BOLD);v.setPadding(4,7,4,7);return v;}
  LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  void add(LinearLayout parent,View child){parent.addView(child);}
  void card(String title,String body){LinearLayout c=column();c.setPadding(22,18,22,18);c.setBackground(shape(panel,24));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,10,0,10);content.addView(c,lp);add(c,text(title,18,Color.WHITE,true));add(c,text(body,14,muted,false));}
  void buttonRow(String[] labels,java.util.function.Consumer<String> onClick){HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);for(String s:labels){TextView b=text(s,13,green,true);b.setGravity(Gravity.CENTER);b.setPadding(20,16,20,16);b.setBackground(shape(panel,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(0,4,10,8);r.addView(b,p);b.setOnClickListener(v->onClick.accept(s));}h.addView(r);content.addView(h);}
  void show(){root=column();root.setBackgroundColor(bg);root.setPadding(18,26,18,10);setContentView(root);add(root,text("⚽  DogukanAnaliz",26,green,true));add(root,text("Futbol • İstatistik • Analiz",13,muted,false));ScrollView scroll=new ScrollView(this);content=column();scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));tabs=new LinearLayout(this);root.addView(tabs);String[] nav={"Ana Sayfa","Takımlar","Analiz","Hakkında"};for(int i=0;i<nav.length;i++){final int j=i;TextView b=text(nav[i],12,i==page?green:muted,i==page);b.setGravity(Gravity.CENTER);tabs.addView(b,new LinearLayout.LayoutParams(0,55,1));b.setOnClickListener(v->{page=j;show();});}if(page==0)home();else if(page==1)teams();else if(page==2)analysis();else about();}
  void home(){add(content,text("Maç merkezi",23,Color.WHITE,true));card("9 organizasyon","Premier League • La Liga • Serie A • Bundesliga • Ligue 1 • Süper Lig\nŞampiyonlar Ligi • Avrupa Ligi • Konferans Ligi");card("Günlük maçlar","Canlı fikstür henüz bağlı değil. Gerçek maçlar için lisanslı futbol veri API'si eklenecek.");card("Veri güvenilirliği","Demo rakamlar gerçek istatistik gibi sunulmaz. Eksik veriler tahmin motoruna aktarılmaz.");}
  void teams(){add(content,text("Takım performansı",23,Color.WHITE,true));card("Trabzonspor","Aynı takımın lig ve Avrupa performansını birbirine karıştırmadan incele.");buttonRow(new String[]{"Süper Lig","Avrupa Ligi","Şampiyonlar Ligi","Konferans Ligi","Tüm maçlar"},s->{competition=s;show();});buttonRow(new String[]{"Son 5","Son 10","Sezon"},s->{period=s;show();});card("Seçim: "+competition+" • "+period,"Oynanan • Galibiyet • Beraberlik • Mağlubiyet\nAtılan / yenilen gol • xG • KG Var • 2.5 Üst\nİç saha ve deplasman performansı\n\nVeri kaynağı bağlanmadı: sayısal istatistik gösterilmiyor.");card("Organizasyon ayrımı","Her istatistik takım + organizasyon + sezon + saha koşulu ile filtrelenecek. Tüm maçlar yalnızca ayrı bir görünüm olarak sunulacak.");}
  void analysis(){add(content,text("Maç analizi",23,Color.WHITE,true));card("Trabzonspor – Hearts","Bu eşleşme yalnızca ekran akışını göstermek için kullanılıyor. Bugün oynandığı doğrulanmadı.");card("Maç sonucu","MS 1 / X / 2 olasılıkları • Tahmin modeli henüz bağlı değil.");card("Gol tahminleri","0.5 / 1.5 / 2.5 / 3.5 üst-alt • KG Var/Yok • İlk yarı gol");card("Detaylı metrikler","xG • şut • korner • kart • takım formu • sakatlık • kadro • iç saha / deplasman");card("Yapay zekâ değerlendirmesi","Her iki takımın oynayacağı organizasyondaki performansı önceliklidir. Yerel lig formu ayrı yardımcı gösterge olur. Veri azsa güven düzeyi düşürülür.");card("Tahmin geçmişi","Tahminlerin ve gerçek sonuçların karşılaştırılması veri bağlantısından sonra etkinleşecek.");}
  void about(){add(content,text("DogukanAnaliz v0.1",23,Color.WHITE,true));card("İlk Android prototipi","Çevrimdışı arayüz prototipi. Henüz API, gerçek maç tahminleri veya canlı skor içermez.");card("Sonraki geliştirme","Futbol API entegrasyonu, model kalibrasyonu, lig bazlı istatistikler, favoriler ve gerçek veri görselleştirmeleri.");}
}
