# DogukanAnaliz Android

Native Java Android MVP UI (offline prototype). Includes navigation, organization-specific team filter, period selector, and match-analysis placeholders. No real football data or predictions are included yet.

## Build
Open in Android Studio (JDK 17), sync Gradle, and build debug APK. Alternatively push to GitHub main and run **Build Android APK** in Actions; download `DogukanAnaliz-debug-apk` artifact.

## Data safety
Do not show invented percentages as real predictions. Future integration must filter by team, competition, season, home/away, and data availability.
